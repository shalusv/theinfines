// src/config/config.js
const config = {
  //   API_URL: "http://localhost:8000/api", // Update the URL as needed
  API_URL: "https://theinfines.com/infines_server/public/api", // Update the URL as needed
};

export default config;
